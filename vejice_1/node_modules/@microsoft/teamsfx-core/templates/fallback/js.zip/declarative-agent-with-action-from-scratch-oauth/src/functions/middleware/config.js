const config = {
  aadAppClientId: process.env.aadAppClientId,
  aadAppTenantId: process.env.aadAppTenantId,
};

module.exports = config;
