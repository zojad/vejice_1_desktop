import React from "react";
import { Welcome } from "./sample/Welcome";

export default function Tab() {
  return (
    <div>
      <Welcome />
    </div>
  );
}
