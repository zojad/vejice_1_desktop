/**
 * Retrive sample data
 * @returns data for list widget
 */
export const getListData = () => [
  {
    id: "id1",
    title: "Lorem ipsum",
    content: "Lorem ipsum dolor sit amet",
  },
  {
    id: "id2",
    title: "Lorem ipsum",
    content: "Lorem ipsum dolor sit amet",
  },
  {
    id: "id3",
    title: "Lorem ipsum",
    content: "Lorem ipsum dolor sit amet",
  },
];
