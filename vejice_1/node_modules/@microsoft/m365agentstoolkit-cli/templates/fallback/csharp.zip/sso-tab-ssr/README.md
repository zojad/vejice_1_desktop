# Welcome to Microsoft 365 Agents Toolkit!

## Quick Start

1. Right-click the 'M365Agent' project in Solution Explorer and select **Microsoft 365 Agents Toolkit > Select Microsoft 365 Account**
2. Sign in to Microsoft 365 Agents Toolkit with a **Microsoft 365 work or school account**
3. Press F5, or select Debug > Start Debugging menu in Visual Studio to start your app
</br>![image](https://raw.githubusercontent.com/OfficeDev/TeamsFx/dev/docs/images/visualstudio/debug/debug-button.png)
4. In the opened web browser, select Add button to install the app in Teams

## Learn more

New to Teams app development or Microsoft 365 Agents Toolkit? Learn more about 
Teams app manifests, deploying to the cloud, and more in the documentation 
at https://aka.ms/teams-toolkit-vs-docs

This sample is configured as interactive server-side rendering.
For more details about Blazor render mode, please refer to [ASP.NET Core Blazor render modes | Microsoft Learn](https://learn.microsoft.com/aspnet/core/blazor/components/render-modes).

Note: This sample will only provision single tenant Microsoft Entra app.
For multi-tenant support, please refer to https://aka.ms/teamsfx-multi-tenant.

## Report an issue

Select Visual Studio > Help > Send Feedback > Report a Problem. 
Or, you can create an issue directly in our GitHub repository: 
https://github.com/OfficeDev/TeamsFx/issues